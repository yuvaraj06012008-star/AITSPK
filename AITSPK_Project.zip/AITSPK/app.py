import streamlit as st
from utils import (
    make_seminar_content, make_slides, make_speech, make_questions,
    make_quiz, make_study_notes, make_pdf, make_pptx, TOPIC_SUGGESTIONS
)

st.set_page_config(page_title="AITSPK | AI Technical Seminar Preparation Kit",
                   page_icon="🎓", layout="wide")

st.markdown("""
<style>
.main {background: #f7f9fc;}
.hero {padding: 1.5rem; border-radius: 18px; background: linear-gradient(120deg,#172554,#2563eb); color:white;}
.hero h1 {color:white; margin-bottom:0.25rem;}
.hero p {color:#dbeafe; margin:0;}
div[data-testid="stMetric"] {background:white; padding:14px; border-radius:12px; border:1px solid #e5e7eb;}
</style>
""", unsafe_allow_html=True)

if "topic" not in st.session_state:
    st.session_state.topic = "Artificial Intelligence in Healthcare"

st.markdown('<div class="hero"><h1>🎓 AITSPK</h1><p>AI Technical Seminar Preparation Kit · Free · No API key required</p></div>', unsafe_allow_html=True)
st.write("")
with st.sidebar:
    st.title("AITSPK Menu")
    page = st.radio("Choose a tool", [
        "Dashboard", "Topic Generator", "Seminar Content", "PPT Creator",
        "Speech Writer", "Viva Questions", "Quiz Generator", "Study Assistant",
        "Export Centre"
    ])
    st.divider()
    st.caption("Runs locally on your Windows computer. Core features work offline.")

def topic_input():
    return st.text_input("Enter your seminar topic", value=st.session_state.topic,
                         key="topic_field")

if page == "Dashboard":
    st.subheader("Welcome to your seminar workspace!")
    st.write("Prepare a technical seminar step by step using simple, structured templates.")
    c1, c2, c3 = st.columns(3)
    c1.metric("Preparation tools", "8")
    c2.metric("API key", "Not needed")
    c3.metric("Project cost", "Free")
    st.subheader("Quick start")
    topic = st.text_input("Your seminar topic", value=st.session_state.topic)
    if st.button("Use this topic", type="primary"):
        st.session_state.topic = topic.strip() or st.session_state.topic
        st.success("Topic saved for this session.")
    st.subheader("Suggested technical topics")
    cols = st.columns(2)
    for i, item in enumerate(TOPIC_SUGGESTIONS):
        if cols[i % 2].button(item, use_container_width=True):
            st.session_state.topic = item
            st.rerun()
    st.info("AITSPK uses local rule-based templates. It does not call a cloud AI service, so no API key or internet connection is needed for the core tools.")

elif page == "Topic Generator":
    st.subheader("💡 Topic Generator")
    area = st.selectbox("Choose a domain", ["Artificial Intelligence", "Data Science", "Cybersecurity", "Cloud Computing", "Internet of Things", "Web Technology", "Computer Networks", "General IT"])
    level = st.selectbox("Difficulty", ["Beginner", "Intermediate", "Advanced"])
    suggestions = {
        "Artificial Intelligence": ["Explainable AI", "Generative AI in Education", "AI-Powered Healthcare", "Edge AI", "Responsible AI"],
        "Data Science": ["Real-Time Data Analytics", "Data Visualization", "Big Data Processing", "Predictive Analytics", "Data Privacy"],
        "Cybersecurity": ["Zero Trust Security", "Phishing Detection", "Blockchain Security", "Cloud Security", "Ransomware Prevention"],
        "Cloud Computing": ["Serverless Computing", "Cloud-Native Applications", "Kubernetes", "Multi-Cloud Strategy", "Cloud Cost Optimization"],
        "Internet of Things": ["Smart Agriculture", "Industrial IoT", "IoT Healthcare", "Edge Computing", "Smart Cities"],
        "Web Technology": ["Progressive Web Apps", "WebAssembly", "Web Accessibility", "API Security", "Modern Web Architecture"],
        "Computer Networks": ["5G Networks", "Software Defined Networking", "Network Function Virtualization", "Wi-Fi 7", "Network Automation"],
        "General IT": ["Green Computing", "Quantum Computing", "Digital Twins", "Human-Computer Interaction", "Open Source Software"]
    }
    st.write(f"### {level} seminar ideas in {area}")
    for t in suggestions[area]:
        if st.button(t, key="topic_"+t):
            st.session_state.topic = t
            st.success(f"Selected: {t}")

elif page == "Seminar Content":
    st.subheader("📝 Seminar Content Generator")
    topic = topic_input()
    audience = st.selectbox("Audience", ["College students", "Beginners", "Technical audience"])
    length = st.selectbox("Content length", ["Short", "Medium", "Detailed"])
    if st.button("Generate seminar content", type="primary"):
        st.session_state.content = make_seminar_content(topic, audience, length)
    if "content" in st.session_state:
        st.text_area("Generated seminar content", st.session_state.content, height=420)
        st.download_button("Download content (.txt)", st.session_state.content, file_name="seminar_content.txt")

elif page == "PPT Creator":
    st.subheader("📊 PPT Slide Content Creator")
    topic = topic_input()
    count = st.slider("Number of slides", 5, 15, 10)
    if st.button("Create slide content", type="primary"):
        st.session_state.slides = make_slides(topic, count)
    if "slides" in st.session_state:
        for slide in st.session_state.slides:
            with st.expander(f"Slide {slide['number']}: {slide['title']}", expanded=True):
                st.write(slide["bullets"])
                st.caption(slide["speaker_note"])
        ppt = make_pptx(topic, st.session_state.slides)
        st.download_button("Download PowerPoint (.pptx)", ppt, file_name="AITSPK_seminar.pptx", mime="application/vnd.openxmlformats-officedocument.presentationml.presentation")

elif page == "Speech Writer":
    st.subheader("🎤 Seminar Speech Writer")
    topic = topic_input()
    duration = st.selectbox("Target speech duration", ["3 minutes", "5 minutes", "7 minutes", "10 minutes"])
    tone = st.selectbox("Speaking style", ["Simple and student-friendly", "Professional", "Confident and engaging"])
    if st.button("Write my speech", type="primary"):
        speech = make_speech(topic, duration, tone)
        st.text_area("Your seminar speech", speech, height=450)
        st.download_button("Download speech (.txt)", speech, file_name="seminar_speech.txt")

elif page == "Viva Questions":
    st.subheader("❓ Viva Question Generator")
    topic = topic_input()
    number = st.slider("Number of questions", 5, 20, 10)
    if st.button("Generate questions", type="primary"):
        st.session_state.questions = make_questions(topic, number)
    if "questions" in st.session_state:
        for i, q in enumerate(st.session_state.questions, 1):
            with st.expander(f"{i}. {q[0]}"):
                st.write("**Answer:**", q[1])
        txt = "\n\n".join(f"Q{i}. {q[0]}\nAnswer: {q[1]}" for i, q in enumerate(st.session_state.questions, 1))
        st.download_button("Download viva Q&A", txt, file_name="viva_questions.txt")

elif page == "Quiz Generator":
    st.subheader("🧠 Quiz Generator")
    topic = topic_input()
    if st.button("Create quiz", type="primary"):
        st.session_state.quiz = make_quiz(topic)
    if "quiz" in st.session_state:
        score = 0
        answers = []
        for i, q in enumerate(st.session_state.quiz):
            ans = st.radio(f"{i+1}. {q['question']}", q["options"], key=f"quiz_{i}")
            answers.append(ans)
        if st.button("Check my score"):
            for ans, q in zip(answers, st.session_state.quiz):
                if ans == q["answer"]:
                    score += 1
            st.success(f"Your score: {score}/{len(st.session_state.quiz)}")
            for i, q in enumerate(st.session_state.quiz, 1):
                st.write(f"{i}. Correct answer: {q['answer']}")

elif page == "Study Assistant":
    st.subheader("📚 Study Assistant")
    topic = topic_input()
    question = st.text_area("What do you want to understand?", placeholder="Example: Explain how this technology works.")
    if st.button("Explain topic", type="primary"):
        if question.strip():
            st.markdown(make_study_notes(topic, question))
        else:
            st.warning("Enter a question first.")

elif page == "Export Centre":
    st.subheader("📦 Export Centre")
    topic = topic_input()
    st.write("Create a ready-to-print seminar preparation PDF.")
    if st.button("Generate seminar PDF", type="primary"):
        content = make_seminar_content(topic, "College students", "Detailed")
        slides = make_slides(topic, 10)
        speech = make_speech(topic, "5 minutes", "Simple and student-friendly")
        pdf = make_pdf(topic, content, slides, speech)
        st.download_button("Download seminar preparation PDF", pdf, file_name="AITSPK_seminar_kit.pdf", mime="application/pdf")
    st.caption("The PPT Creator page separately provides a PowerPoint download.")
