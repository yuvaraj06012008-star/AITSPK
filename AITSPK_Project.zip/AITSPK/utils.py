from io import BytesIO
import re

TOPIC_SUGGESTIONS = [
    "Artificial Intelligence in Healthcare", "Generative AI", "Machine Learning",
    "Cybersecurity", "Cloud Computing", "Internet of Things",
    "Blockchain Technology", "Quantum Computing"
]

def clean_topic(topic):
    return topic.strip() if topic and topic.strip() else "Emerging Technology"

def make_seminar_content(topic, audience="College students", length="Medium"):
    topic = clean_topic(topic)
    detail = {
        "Short": "This seminar introduces the basic idea and its importance.",
        "Medium": "This seminar explains the concept, working process, applications, benefits and challenges.",
        "Detailed": "This seminar provides a structured overview of the background, core concepts, architecture, working process, applications, advantages, limitations, challenges and future scope."
    }.get(length, "")
    sections = [
        ("1. Introduction", f"{topic} is an important area of technology. {detail} It is useful to understand how it works and where it can be applied."),
        ("2. Background", f"The development of {topic} is connected to the growing need for efficient, reliable and scalable digital solutions. Research and practical improvements continue to shape this field."),
        ("3. Core Concept", f"The central idea of {topic} is to solve a problem using a defined set of methods, tools and processes. A good understanding begins with identifying the input, processing steps and expected output."),
        ("4. Working Principle", f"A typical {topic} solution follows a sequence: collect or provide input, process the input, apply the relevant method, produce an output, and evaluate the result. The exact components depend on the implementation."),
        ("5. Applications", f"{topic} can be discussed in relation to education, healthcare, business, industry, communication and public services. The suitability of each application depends on cost, accuracy, privacy and user needs."),
        ("6. Advantages", "Potential benefits include improved efficiency, faster processing, better access to information, automation of repetitive tasks and support for informed decisions."),
        ("7. Challenges and Limitations", "Common challenges include implementation cost, security, privacy, reliability, technical complexity, maintenance and the need for skilled people. These limitations should be evaluated before deployment."),
        ("8. Future Scope", f"The future of {topic} may include improved performance, stronger security, wider accessibility, better integration and more responsible use. New developments should be assessed using reliable technical sources."),
        ("9. Conclusion", f"To conclude, {topic} is a relevant technical subject with practical opportunities as well as limitations. Understanding its principles helps students evaluate its real-world value.")
    ]
    return f"SEMINAR: {topic}\nAudience: {audience}\n\n" + "\n\n".join(h + "\n" + p for h,p in sections) + "\n\nNote: Add verified statistics, diagrams and references from trusted sources before presenting."

def make_slides(topic, count=10):
    topic = clean_topic(topic)
    titles = [
        "Title", "Introduction", "Background and Need", "Core Concepts",
        "Architecture / Main Components", "Working Principle", "Applications",
        "Advantages", "Challenges and Limitations", "Future Scope and Conclusion",
        "Case Study", "Comparison", "Security and Ethics", "References", "Thank You"
    ]
    result = []
    for i in range(count):
        title = titles[i] if i < len(titles) else f"Additional Points {i+1}"
        bullets = [
            f"Overview of {topic}",
            "Key idea and important terminology",
            "Practical example or diagram to explain the concept"
        ]
        if i == 0: bullets = [topic, "Technical Seminar", "Presented by: [Your Name]"]
        if title == "Applications": bullets = ["Education and learning", "Healthcare and industry", "Business and public services"]
        if title == "Advantages": bullets = ["Efficiency and productivity", "Automation of repetitive tasks", "Improved access to useful information"]
        if title == "Challenges and Limitations": bullets = ["Cost and implementation complexity", "Privacy, security and reliability", "Maintenance and skill requirements"]
        if title == "Future Scope and Conclusion": bullets = ["Emerging developments", "Responsible and secure adoption", f"{topic} has opportunities and limitations"]
        result.append({"number": i+1, "title": title, "bullets": bullets,
                       "speaker_note": f"Explain how this slide connects to {topic}. Add a relevant verified example."})
    return result

def make_speech(topic, duration="5 minutes", tone="Simple and student-friendly"):
    topic = clean_topic(topic)
    return f"""Good morning respected teachers and my dear friends.

Today, I am going to present my technical seminar on {topic}.

First, let us understand why this topic is important. Technology is developing quickly, and new methods are helping people solve problems in education, business, healthcare and many other fields.

The main concept of {topic} is to use suitable technical methods and tools to achieve a useful result. To understand it, we should look at its basic concepts, components and working process.

In a typical system, input is provided, the system processes that input, and an output is produced. The exact process depends on the design and application. A clear diagram or practical example can make this process easier to understand.

There are several possible applications of {topic}. It can support different sectors when it is implemented carefully. Its benefits may include better efficiency, reduced repetitive work and improved access to information.

However, we must also consider challenges such as cost, privacy, security, reliability and maintenance. Technology should be used responsibly, and its results should be checked.

In the future, {topic} may develop further through research, better tools and wider adoption.

To conclude, {topic} is an interesting and useful technical area. Learning its fundamentals helps us understand both its opportunities and its limitations.

Thank you for listening. I am happy to answer your questions.
"""

def make_questions(topic, number=10):
    topic = clean_topic(topic)
    base = [
        (f"What is {topic}?", f"{topic} is a technical field or approach used to address particular problems through relevant concepts, methods and tools."),
        ("Why is this topic important?", "It helps address practical needs and can improve efficiency, capability or access when used appropriately."),
        ("What are its main components?", "The components depend on the specific system. They commonly include input, processing, storage or communication, and output."),
        ("Explain its working principle.", "A typical process accepts input, processes it according to defined rules or methods, and produces an output that can be evaluated."),
        ("Mention two applications.", "Applications depend on the topic; examples may be found in education, healthcare, industry and business."),
        ("What are the advantages?", "Possible advantages include efficiency, automation, consistency and improved access to information."),
        ("What are the limitations?", "Limitations may include cost, complexity, security risks, privacy concerns and maintenance requirements."),
        ("What security issues should be considered?", "Access control, data protection, secure communication, updates and monitoring should be considered."),
        ("What is the future scope?", "Future work may improve performance, affordability, reliability, accessibility and responsible use."),
        ("Give a real-world example.", f"A suitable example should show how {topic} is used to solve a specific problem. Select a verified case study relevant to your seminar.")
    ]
    return (base * ((number + len(base)-1)//len(base)))[:number]

def make_quiz(topic):
    t = clean_topic(topic)
    return [
        {"question": f"What should you identify first when studying {t}?", "options": ["Its basic concept", "Only its price", "Only its logo", "None of these"], "answer": "Its basic concept"},
        {"question": "Which is a good practice in a technical seminar?", "options": ["Use unverified facts", "Explain with examples", "Avoid preparation", "Read tiny text"], "answer": "Explain with examples"},
        {"question": "Which issue is important when deploying technology?", "options": ["Privacy and security", "Slide colour only", "Font size only", "None"], "answer": "Privacy and security"},
        {"question": "What is the purpose of a conclusion?", "options": ["Introduce a new topic", "Summarize key points", "Remove the main idea", "Add unrelated content"], "answer": "Summarize key points"},
        {"question": "What makes a technical claim trustworthy?", "options": ["A random post", "A verified reliable source", "A guess", "No source"], "answer": "A verified reliable source"}
    ]

def make_study_notes(topic, question):
    topic = clean_topic(topic)
    return f"""### Study explanation: {topic}

**Your question:** {question}

Start with the definition of {topic}. Break the subject into three parts:

1. **Concept:** What problem does it solve? Identify the important terms.
2. **Working:** Trace the input, processing steps and output. Draw a simple block diagram.
3. **Application:** Choose one real-world example and explain why the technology is useful there.

**How to prepare:** Write a one-sentence definition, learn five key terms, draw one diagram, and practise explaining one example in your own words.

**Important:** This is an offline study guide, not a live generative AI model. Verify topic-specific technical details using your textbook or trusted references."""

def make_pptx(topic, slides):
    try:
        from pptx import Presentation
        from pptx.util import Inches, Pt
        prs = Presentation()
        for item in slides:
            slide = prs.slides.add_slide(prs.slide_layouts[1])
            slide.shapes.title.text = item["title"]
            body = slide.placeholders[1].text_frame
            body.clear()
            for j, bullet in enumerate(item["bullets"]):
                p = body.paragraphs[0] if j == 0 else body.add_paragraph()
                p.text = bullet
                p.font.size = Pt(24)
        out = BytesIO()
        prs.save(out)
        return out.getvalue()
    except Exception as e:
        raise RuntimeError("PowerPoint export requires python-pptx. Install requirements.txt.") from e

def make_pdf(topic, content, slides, speech):
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.units import inch
    out = BytesIO()
    doc = SimpleDocTemplate(out, pagesize=A4, rightMargin=0.65*inch, leftMargin=0.65*inch)
    styles = getSampleStyleSheet()
    story = [Paragraph("AITSPK - Seminar Preparation Kit", styles["Title"]),
             Paragraph(topic, styles["Heading1"]), Spacer(1, 12)]
    for line in content.splitlines():
        if not line.strip():
            story.append(Spacer(1, 6))
        elif line[:1].isdigit() and ". " in line[:5]:
            story.append(Paragraph(line, styles["Heading2"]))
        else:
            story.append(Paragraph(line.replace("&", "&amp;"), styles["BodyText"]))
    story.append(PageBreak())
    story.append(Paragraph("PowerPoint Slide Plan", styles["Heading1"]))
    for s in slides:
        story.append(Paragraph(f"Slide {s['number']}: {s['title']}", styles["Heading2"]))
        for b in s["bullets"]:
            story.append(Paragraph("• " + b.replace("&", "&amp;"), styles["BodyText"]))
    story.append(PageBreak())
    story.append(Paragraph("Presentation Speech", styles["Heading1"]))
    for para in speech.split("\n\n"):
        story.append(Paragraph(para.replace("&", "&amp;"), styles["BodyText"]))
        story.append(Spacer(1, 8))
    doc.build(story)
    return out.getvalue()
