# AITSPK – AI Technical Seminar Preparation Kit

A free, local Python + Streamlit project for preparing technical seminars. No API key is needed.

## Features
- Topic suggestions by technical domain
- Seminar content outline
- PowerPoint slide content and `.pptx` export
- Presentation speech draft
- Viva questions and answers
- Multiple-choice quiz
- Offline study guide
- PDF seminar kit export

## Important note
This project uses offline templates and rule-based generation. It is **not a cloud LLM** and does not generate verified, up-to-the-minute facts. Add current facts, diagrams, case studies and references from trusted sources before presenting.

## Windows installation (VS Code)

1. Install Python 3.10 or newer and VS Code.
2. Extract the ZIP file.
3. Open the `AITSPK` folder in VS Code.
4. Open Terminal → New Terminal.
5. Create a virtual environment:

   ```powershell
   py -m venv .venv
   ```

6. Activate it:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, run:

   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\.venv\Scripts\Activate.ps1
   ```

7. Install packages:

   ```powershell
   python -m pip install -r requirements.txt
   ```

8. Start the application:

   ```powershell
   python -m streamlit run app.py
   ```

9. Streamlit opens the app in your browser, usually at `http://localhost:8501`.

## Project structure

```text
AITSPK/
├── app.py
├── utils.py
├── requirements.txt
├── README.md
└── run_AITSPK.bat
```

## One-click launch
After installing dependencies, double-click `run_AITSPK.bat`.

## Troubleshooting
- If `py` is not recognized, reinstall Python and enable **Add Python to PATH**.
- If a package is missing, activate `.venv` and run `python -m pip install -r requirements.txt`.
- Keep the terminal open while using the app.
