@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found.
    echo Run the setup steps in README.md first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m streamlit run app.py
pause
